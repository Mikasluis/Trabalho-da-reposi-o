﻿namespace Cadastro_LF
{
    partial class frmCadastro_Cliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbl_Nome = new Label();
            lbl_CPF = new Label();
            txt_Nome = new TextBox();
            txt_CPF = new TextBox();
            bnt_Cadastro = new Button();
            lbl_Cliente = new Label();
            menuStrip1 = new MenuStrip();
            sairToolStripMenuItem = new ToolStripMenuItem();
            sairToolStripMenuItem1 = new ToolStripMenuItem();
            lbl_Time = new Label();
            txt_Time = new TextBox();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // lbl_Nome
            // 
            lbl_Nome.AutoSize = true;
            lbl_Nome.Font = new Font("Yu Gothic UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_Nome.ForeColor = Color.LightGreen;
            lbl_Nome.Location = new Point(254, 203);
            lbl_Nome.Name = "lbl_Nome";
            lbl_Nome.Size = new Size(55, 20);
            lbl_Nome.TabIndex = 0;
            lbl_Nome.Text = "Nome:";
            // 
            // lbl_CPF
            // 
            lbl_CPF.AutoSize = true;
            lbl_CPF.Font = new Font("Yu Gothic UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_CPF.ForeColor = Color.LightGreen;
            lbl_CPF.Location = new Point(254, 256);
            lbl_CPF.Name = "lbl_CPF";
            lbl_CPF.Size = new Size(39, 20);
            lbl_CPF.TabIndex = 1;
            lbl_CPF.Text = "CPF:";
            // 
            // txt_Nome
            // 
            txt_Nome.Location = new Point(339, 204);
            txt_Nome.Name = "txt_Nome";
            txt_Nome.Size = new Size(296, 23);
            txt_Nome.TabIndex = 2;
            // 
            // txt_CPF
            // 
            txt_CPF.Location = new Point(339, 257);
            txt_CPF.Name = "txt_CPF";
            txt_CPF.Size = new Size(296, 23);
            txt_CPF.TabIndex = 3;
            // 
            // bnt_Cadastro
            // 
            bnt_Cadastro.BackColor = Color.LightGreen;
            bnt_Cadastro.FlatStyle = FlatStyle.Flat;
            bnt_Cadastro.Location = new Point(339, 377);
            bnt_Cadastro.Name = "bnt_Cadastro";
            bnt_Cadastro.Size = new Size(296, 182);
            bnt_Cadastro.TabIndex = 4;
            bnt_Cadastro.Text = "Cadastrar";
            bnt_Cadastro.UseVisualStyleBackColor = false;
            bnt_Cadastro.Click += bnt_Cadastro_Click;
            // 
            // lbl_Cliente
            // 
            lbl_Cliente.AutoSize = true;
            lbl_Cliente.Font = new Font("Yu Gothic UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_Cliente.ForeColor = Color.LightGreen;
            lbl_Cliente.Location = new Point(266, 94);
            lbl_Cliente.Name = "lbl_Cliente";
            lbl_Cliente.Size = new Size(449, 65);
            lbl_Cliente.TabIndex = 5;
            lbl_Cliente.Text = "Cadastro de cliente";
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { sairToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1081, 24);
            menuStrip1.TabIndex = 6;
            menuStrip1.Text = "menuStrip1";
            // 
            // sairToolStripMenuItem
            // 
            sairToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { sairToolStripMenuItem1 });
            sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            sairToolStripMenuItem.Size = new Size(50, 20);
            sairToolStripMenuItem.Text = "Menu";
            sairToolStripMenuItem.Click += sairToolStripMenuItem_Click;
            // 
            // sairToolStripMenuItem1
            // 
            sairToolStripMenuItem1.Name = "sairToolStripMenuItem1";
            sairToolStripMenuItem1.Size = new Size(180, 22);
            sairToolStripMenuItem1.Text = "Sair";
            sairToolStripMenuItem1.Click += sairToolStripMenuItem1_Click;
            // 
            // lbl_Time
            // 
            lbl_Time.AutoSize = true;
            lbl_Time.FlatStyle = FlatStyle.Flat;
            lbl_Time.Font = new Font("Yu Gothic UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_Time.ForeColor = Color.LightGreen;
            lbl_Time.Location = new Point(190, 311);
            lbl_Time.Name = "lbl_Time";
            lbl_Time.Size = new Size(152, 20);
            lbl_Time.TabIndex = 7;
            lbl_Time.Text = "Torce para qual time:";
            // 
            // txt_Time
            // 
            txt_Time.Location = new Point(348, 311);
            txt_Time.Name = "txt_Time";
            txt_Time.Size = new Size(287, 23);
            txt_Time.TabIndex = 8;
            // 
            // frmCadastro_Cliente
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkCyan;
            ClientSize = new Size(1081, 636);
            Controls.Add(txt_Time);
            Controls.Add(lbl_Time);
            Controls.Add(lbl_Cliente);
            Controls.Add(bnt_Cadastro);
            Controls.Add(txt_CPF);
            Controls.Add(txt_Nome);
            Controls.Add(lbl_CPF);
            Controls.Add(lbl_Nome);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "frmCadastro_Cliente";
            Text = "frmCadastro_Cliente";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbl_Nome;
        private Label lbl_CPF;
        private TextBox txt_Nome;
        private TextBox txt_CPF;
        private Button bnt_Cadastro;
        private Label lbl_Cliente;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem sairToolStripMenuItem;
        private ToolStripMenuItem sairToolStripMenuItem1;
        private Label lbl_Time;
        private TextBox txt_Time;
    }
}