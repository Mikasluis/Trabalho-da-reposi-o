﻿namespace Cadastro_LF
{
    partial class frmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnClientes = new Button();
            btnEstoque = new Button();
            btnSuporte = new Button();
            btnSair = new Button();
            lblPaineldeControle = new Label();
            lbl_ola = new Label();
            menuStrip1 = new MenuStrip();
            sistemaToolStripMenuItem = new ToolStripMenuItem();
            trocaDeUsuárioToolStripMenuItem = new ToolStripMenuItem();
            saiDoSistemaToolStripMenuItem = new ToolStripMenuItem();
            cadastroToolStripMenuItem = new ToolStripMenuItem();
            equipamentosToolStripMenuItem = new ToolStripMenuItem();
            clientesToolStripMenuItem = new ToolStripMenuItem();
            ajudaToolStripMenuItem = new ToolStripMenuItem();
            sobreToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // btnClientes
            // 
            btnClientes.BackColor = Color.PaleGreen;
            btnClientes.Cursor = Cursors.Hand;
            btnClientes.FlatStyle = FlatStyle.Flat;
            btnClientes.Font = new Font("Yu Gothic", 11.25F, FontStyle.Bold);
            btnClientes.Location = new Point(612, 202);
            btnClientes.Name = "btnClientes";
            btnClientes.Size = new Size(229, 77);
            btnClientes.TabIndex = 0;
            btnClientes.Text = "Clientes";
            btnClientes.UseVisualStyleBackColor = false;
            // 
            // btnEstoque
            // 
            btnEstoque.BackColor = Color.PaleGreen;
            btnEstoque.Cursor = Cursors.Hand;
            btnEstoque.FlatStyle = FlatStyle.Flat;
            btnEstoque.Font = new Font("Yu Gothic", 11.25F, FontStyle.Bold);
            btnEstoque.Location = new Point(612, 302);
            btnEstoque.Name = "btnEstoque";
            btnEstoque.Size = new Size(229, 74);
            btnEstoque.TabIndex = 1;
            btnEstoque.Text = "Estoque";
            btnEstoque.UseVisualStyleBackColor = false;
            // 
            // btnSuporte
            // 
            btnSuporte.AutoEllipsis = true;
            btnSuporte.BackColor = Color.PaleGreen;
            btnSuporte.Cursor = Cursors.Hand;
            btnSuporte.FlatStyle = FlatStyle.Flat;
            btnSuporte.Font = new Font("Yu Gothic", 11.25F, FontStyle.Bold);
            btnSuporte.Location = new Point(612, 398);
            btnSuporte.Name = "btnSuporte";
            btnSuporte.Size = new Size(229, 74);
            btnSuporte.TabIndex = 2;
            btnSuporte.Text = "Suporte";
            btnSuporte.UseVisualStyleBackColor = false;
            // 
            // btnSair
            // 
            btnSair.BackColor = Color.PaleGreen;
            btnSair.Cursor = Cursors.Hand;
            btnSair.FlatStyle = FlatStyle.Flat;
            btnSair.Font = new Font("Yu Gothic", 11.25F, FontStyle.Bold);
            btnSair.Location = new Point(612, 489);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(229, 74);
            btnSair.TabIndex = 3;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = false;
            btnSair.Click += bntSair_Click;
            // 
            // lblPaineldeControle
            // 
            lblPaineldeControle.AutoSize = true;
            lblPaineldeControle.BorderStyle = BorderStyle.Fixed3D;
            lblPaineldeControle.Font = new Font("Yu Gothic", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPaineldeControle.ForeColor = Color.PaleGreen;
            lblPaineldeControle.Location = new Point(62, 82);
            lblPaineldeControle.Name = "lblPaineldeControle";
            lblPaineldeControle.Size = new Size(451, 63);
            lblPaineldeControle.TabIndex = 4;
            lblPaineldeControle.Text = "Painel de controle";
            lblPaineldeControle.Click += label1_Click;
            // 
            // lbl_ola
            // 
            lbl_ola.AutoSize = true;
            lbl_ola.BorderStyle = BorderStyle.Fixed3D;
            lbl_ola.Font = new Font("Yu Gothic", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_ola.ForeColor = Color.PaleGreen;
            lbl_ola.Location = new Point(178, 225);
            lbl_ola.Name = "lbl_ola";
            lbl_ola.Size = new Size(179, 63);
            lbl_ola.TabIndex = 5;
            lbl_ola.Text = "GGWP";
            lbl_ola.Click += label1_Click_1;
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { sistemaToolStripMenuItem, cadastroToolStripMenuItem, ajudaToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1134, 24);
            menuStrip1.TabIndex = 6;
            menuStrip1.Text = "menuStrip1";
            // 
            // sistemaToolStripMenuItem
            // 
            sistemaToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { trocaDeUsuárioToolStripMenuItem, saiDoSistemaToolStripMenuItem });
            sistemaToolStripMenuItem.Name = "sistemaToolStripMenuItem";
            sistemaToolStripMenuItem.Size = new Size(60, 20);
            sistemaToolStripMenuItem.Text = "Sistema";
            // 
            // trocaDeUsuárioToolStripMenuItem
            // 
            trocaDeUsuárioToolStripMenuItem.Name = "trocaDeUsuárioToolStripMenuItem";
            trocaDeUsuárioToolStripMenuItem.Size = new Size(161, 22);
            trocaDeUsuárioToolStripMenuItem.Text = "Troca de usuário";
            trocaDeUsuárioToolStripMenuItem.Click += trocaDeUsuárioToolStripMenuItem_Click;
            // 
            // saiDoSistemaToolStripMenuItem
            // 
            saiDoSistemaToolStripMenuItem.Name = "saiDoSistemaToolStripMenuItem";
            saiDoSistemaToolStripMenuItem.Size = new Size(161, 22);
            saiDoSistemaToolStripMenuItem.Text = "Sai do sistema";
            saiDoSistemaToolStripMenuItem.Click += saiDoSistemaToolStripMenuItem_Click;
            // 
            // cadastroToolStripMenuItem
            // 
            cadastroToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { equipamentosToolStripMenuItem, clientesToolStripMenuItem });
            cadastroToolStripMenuItem.Name = "cadastroToolStripMenuItem";
            cadastroToolStripMenuItem.Size = new Size(66, 20);
            cadastroToolStripMenuItem.Text = "Cadastro";
            // 
            // equipamentosToolStripMenuItem
            // 
            equipamentosToolStripMenuItem.Name = "equipamentosToolStripMenuItem";
            equipamentosToolStripMenuItem.Size = new Size(180, 22);
            equipamentosToolStripMenuItem.Text = "Equipamentos";
            equipamentosToolStripMenuItem.Click += equipamentosToolStripMenuItem_Click;
            // 
            // clientesToolStripMenuItem
            // 
            clientesToolStripMenuItem.Name = "clientesToolStripMenuItem";
            clientesToolStripMenuItem.Size = new Size(180, 22);
            clientesToolStripMenuItem.Text = "Clientes";
            clientesToolStripMenuItem.Click += clientesToolStripMenuItem_Click;
            // 
            // ajudaToolStripMenuItem
            // 
            ajudaToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { sobreToolStripMenuItem });
            ajudaToolStripMenuItem.Name = "ajudaToolStripMenuItem";
            ajudaToolStripMenuItem.Size = new Size(50, 20);
            ajudaToolStripMenuItem.Text = "Ajuda";
            // 
            // sobreToolStripMenuItem
            // 
            sobreToolStripMenuItem.Name = "sobreToolStripMenuItem";
            sobreToolStripMenuItem.Size = new Size(104, 22);
            sobreToolStripMenuItem.Text = "Sobre";
            sobreToolStripMenuItem.Click += sobreToolStripMenuItem_Click;
            // 
            // frmMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkCyan;
            ClientSize = new Size(1134, 641);
            Controls.Add(lbl_ola);
            Controls.Add(lblPaineldeControle);
            Controls.Add(btnSair);
            Controls.Add(btnSuporte);
            Controls.Add(btnEstoque);
            Controls.Add(btnClientes);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "frmMenu";
            Text = "frmMenu";
            FormClosed += frmMenu_FormClosed;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnClientes;
        private Button btnEstoque;
        private Button btnSuporte;
        private Button btnSair;
        private Label lblPaineldeControle;
        private Label lbl_ola;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem sistemaToolStripMenuItem;
        private ToolStripMenuItem trocaDeUsuárioToolStripMenuItem;
        private ToolStripMenuItem saiDoSistemaToolStripMenuItem;
        private ToolStripMenuItem cadastroToolStripMenuItem;
        private ToolStripMenuItem equipamentosToolStripMenuItem;
        private ToolStripMenuItem clientesToolStripMenuItem;
        private ToolStripMenuItem ajudaToolStripMenuItem;
        private ToolStripMenuItem sobreToolStripMenuItem;
    }
}