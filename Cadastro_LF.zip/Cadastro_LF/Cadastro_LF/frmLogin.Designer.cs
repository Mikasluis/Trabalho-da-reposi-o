﻿namespace Cadastro_LF
{
    partial class frmLogin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            bnt_Cadastrar = new Button();
            lbl_Nome = new Label();
            lbl_Idade = new Label();
            txt_Nome = new TextBox();
            txt_Idade = new TextBox();
            lbl_Tirulo = new Label();
            SuspendLayout();
            // 
            // bnt_Cadastrar
            // 
            bnt_Cadastrar.BackColor = Color.PaleGreen;
            bnt_Cadastrar.Cursor = Cursors.Hand;
            bnt_Cadastrar.FlatStyle = FlatStyle.Popup;
            bnt_Cadastrar.Location = new Point(245, 437);
            bnt_Cadastrar.Name = "bnt_Cadastrar";
            bnt_Cadastrar.Size = new Size(558, 161);
            bnt_Cadastrar.TabIndex = 0;
            bnt_Cadastrar.Text = "Cadastrar";
            bnt_Cadastrar.UseVisualStyleBackColor = false;
            bnt_Cadastrar.Click += bnt_Cadastrar_Click;
            // 
            // lbl_Nome
            // 
            lbl_Nome.AutoSize = true;
            lbl_Nome.BackColor = SystemColors.ControlDark;
            lbl_Nome.Font = new Font("Yu Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_Nome.Location = new Point(298, 273);
            lbl_Nome.Name = "lbl_Nome";
            lbl_Nome.Size = new Size(58, 19);
            lbl_Nome.TabIndex = 1;
            lbl_Nome.Text = "Nome:";
            // 
            // lbl_Idade
            // 
            lbl_Idade.AutoSize = true;
            lbl_Idade.BackColor = SystemColors.ControlDark;
            lbl_Idade.Font = new Font("Yu Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_Idade.Location = new Point(301, 351);
            lbl_Idade.Name = "lbl_Idade";
            lbl_Idade.Size = new Size(55, 19);
            lbl_Idade.TabIndex = 2;
            lbl_Idade.Text = "Idade:";
            lbl_Idade.Click += label2_Click;
            // 
            // txt_Nome
            // 
            txt_Nome.BackColor = SystemColors.ScrollBar;
            txt_Nome.Location = new Point(387, 273);
            txt_Nome.Name = "txt_Nome";
            txt_Nome.Size = new Size(276, 23);
            txt_Nome.TabIndex = 3;
            txt_Nome.Text = "ex: Jonas";
            // 
            // txt_Idade
            // 
            txt_Idade.BackColor = SystemColors.ScrollBar;
            txt_Idade.Location = new Point(387, 347);
            txt_Idade.Name = "txt_Idade";
            txt_Idade.Size = new Size(276, 23);
            txt_Idade.TabIndex = 4;
            txt_Idade.Text = "dd/mm/aaaa";
            // 
            // lbl_Tirulo
            // 
            lbl_Tirulo.AutoSize = true;
            lbl_Tirulo.Cursor = Cursors.No;
            lbl_Tirulo.Font = new Font("Yu Gothic", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_Tirulo.ForeColor = Color.PaleGreen;
            lbl_Tirulo.Location = new Point(301, 158);
            lbl_Tirulo.Name = "lbl_Tirulo";
            lbl_Tirulo.Size = new Size(115, 42);
            lbl_Tirulo.TabIndex = 5;
            lbl_Tirulo.Text = "Login:";
            lbl_Tirulo.Click += label1_Click;
            // 
            // frmLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkCyan;
            ClientSize = new Size(1162, 675);
            Controls.Add(lbl_Tirulo);
            Controls.Add(txt_Idade);
            Controls.Add(txt_Nome);
            Controls.Add(lbl_Idade);
            Controls.Add(lbl_Nome);
            Controls.Add(bnt_Cadastrar);
            Name = "frmLogin";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button bnt_Cadastrar;
        private Label lbl_Nome;
        private Label lbl_Idade;
        private TextBox txt_Nome;
        private TextBox txt_Idade;
        private Label lbl_Tirulo;
    }
}
