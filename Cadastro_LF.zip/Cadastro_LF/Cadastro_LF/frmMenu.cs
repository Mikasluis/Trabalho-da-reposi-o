﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cadastro_LF
{
    public partial class frmMenu : Form
    {
        //construtor customizado q emite o nome do usuário
        public frmMenu(string nomedousuario)
        {
            InitializeComponent();
            lbl_ola.Text = "Bem-Vindo(a), " + nomedousuario + "!";
        }
        public frmMenu()
        {
            InitializeComponent();
        }

        private void bntSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void frmMenu_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void trocaDeUsuárioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saiDoSistemaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //encerra a execução
            Application.Exit();
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSobre sobre = new frmSobre();
            sobre.ShowDialog();
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCadastro_Cliente telaCadastro = new frmCadastro_Cliente();
            this.Close();
            telaCadastro.ShowDialog();

        }

        private void equipamentosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEquipamentos Cadastro_Equipamentos = new frmEquipamentos();
            this.Close();
            Cadastro_Equipamentos.ShowDialog();
        }
    }
}
