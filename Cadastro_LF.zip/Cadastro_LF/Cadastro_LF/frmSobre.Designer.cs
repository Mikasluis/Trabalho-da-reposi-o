﻿namespace Cadastro_LF
{
    partial class frmSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbl_nome = new Label();
            bnt_Ok = new Button();
            SuspendLayout();
            // 
            // lbl_nome
            // 
            lbl_nome.AutoSize = true;
            lbl_nome.BackColor = Color.LightGreen;
            lbl_nome.Font = new Font("Yu Gothic", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_nome.Location = new Point(47, 63);
            lbl_nome.Name = "lbl_nome";
            lbl_nome.Size = new Size(502, 42);
            lbl_nome.TabIndex = 0;
            lbl_nome.Text = "Luis Fernando de Oliveira Silva";
            // 
            // bnt_Ok
            // 
            bnt_Ok.BackColor = Color.LightGreen;
            bnt_Ok.Cursor = Cursors.Hand;
            bnt_Ok.FlatStyle = FlatStyle.Flat;
            bnt_Ok.Location = new Point(587, 31);
            bnt_Ok.Name = "bnt_Ok";
            bnt_Ok.Size = new Size(201, 407);
            bnt_Ok.TabIndex = 1;
            bnt_Ok.Text = "OK";
            bnt_Ok.UseVisualStyleBackColor = false;
            bnt_Ok.Click += bnt_Ok_Click;
            // 
            // frmSobre
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources._71GpyM8n5nL__AC_UF1000_1000_QL80_;
            ClientSize = new Size(800, 450);
            Controls.Add(bnt_Ok);
            Controls.Add(lbl_nome);
            Name = "frmSobre";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbl_nome;
        private Button bnt_Ok;
    }
}