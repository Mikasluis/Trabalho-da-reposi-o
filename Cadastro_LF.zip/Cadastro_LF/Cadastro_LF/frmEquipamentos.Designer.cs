﻿namespace Cadastro_LF
{
    partial class frmEquipamentos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbl_Equipamentos = new Label();
            lbl_Funcionario = new Label();
            txt_Funcionario = new TextBox();
            cmb_Equipamentos = new ComboBox();
            label1 = new Label();
            bnt_Cadastrar = new Button();
            menuStrip1 = new MenuStrip();
            menuToolStripMenuItem = new ToolStripMenuItem();
            sairToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // lbl_Equipamentos
            // 
            lbl_Equipamentos.AutoSize = true;
            lbl_Equipamentos.Font = new Font("Yu Gothic UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_Equipamentos.Location = new Point(316, 252);
            lbl_Equipamentos.Name = "lbl_Equipamentos";
            lbl_Equipamentos.Size = new Size(110, 20);
            lbl_Equipamentos.TabIndex = 0;
            lbl_Equipamentos.Text = "Equipamentos:";
            // 
            // lbl_Funcionario
            // 
            lbl_Funcionario.AutoSize = true;
            lbl_Funcionario.Font = new Font("Yu Gothic UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_Funcionario.Location = new Point(316, 299);
            lbl_Funcionario.Name = "lbl_Funcionario";
            lbl_Funcionario.Size = new Size(94, 20);
            lbl_Funcionario.TabIndex = 2;
            lbl_Funcionario.Text = "Funcionário:";
            lbl_Funcionario.Click += lbl_Funcionario_Click;
            // 
            // txt_Funcionario
            // 
            txt_Funcionario.Location = new Point(432, 300);
            txt_Funcionario.Name = "txt_Funcionario";
            txt_Funcionario.Size = new Size(219, 23);
            txt_Funcionario.TabIndex = 3;
            // 
            // cmb_Equipamentos
            // 
            cmb_Equipamentos.FormattingEnabled = true;
            cmb_Equipamentos.Items.AddRange(new object[] { "Cabo Bluethoot", "Arquivo JSON", "Chave da API", "Cabo Sem Fio", "Monitor Sem Led", "Lâmpada que não acende" });
            cmb_Equipamentos.Location = new Point(432, 253);
            cmb_Equipamentos.Name = "cmb_Equipamentos";
            cmb_Equipamentos.Size = new Size(219, 23);
            cmb_Equipamentos.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Yu Gothic UI", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(331, 131);
            label1.Name = "label1";
            label1.Size = new Size(412, 45);
            label1.TabIndex = 5;
            label1.Text = "Cadastro de Equipamentos";
            // 
            // bnt_Cadastrar
            // 
            bnt_Cadastrar.BackColor = Color.LightGreen;
            bnt_Cadastrar.FlatStyle = FlatStyle.Flat;
            bnt_Cadastrar.ForeColor = Color.Black;
            bnt_Cadastrar.Location = new Point(388, 405);
            bnt_Cadastrar.Name = "bnt_Cadastrar";
            bnt_Cadastrar.Size = new Size(304, 152);
            bnt_Cadastrar.TabIndex = 6;
            bnt_Cadastrar.Text = "Cadastrar";
            bnt_Cadastrar.UseVisualStyleBackColor = false;
            bnt_Cadastrar.Click += bnt_Cadastrar_Click;
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { menuToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1174, 24);
            menuStrip1.TabIndex = 7;
            menuStrip1.Text = "menuStrip1";
            // 
            // menuToolStripMenuItem
            // 
            menuToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { sairToolStripMenuItem });
            menuToolStripMenuItem.ForeColor = Color.Black;
            menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            menuToolStripMenuItem.Size = new Size(50, 20);
            menuToolStripMenuItem.Text = "Menu";
            // 
            // sairToolStripMenuItem
            // 
            sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            sairToolStripMenuItem.Size = new Size(180, 22);
            sairToolStripMenuItem.Text = "Sair";
            sairToolStripMenuItem.Click += sairToolStripMenuItem_Click;
            // 
            // frmEquipamentos
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkCyan;
            BackgroundImage = Properties.Resources.images;
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(1174, 637);
            Controls.Add(bnt_Cadastrar);
            Controls.Add(label1);
            Controls.Add(cmb_Equipamentos);
            Controls.Add(txt_Funcionario);
            Controls.Add(lbl_Funcionario);
            Controls.Add(lbl_Equipamentos);
            Controls.Add(menuStrip1);
            ForeColor = Color.LightGreen;
            MainMenuStrip = menuStrip1;
            Name = "frmEquipamentos";
            Text = "frmEquipamentos";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbl_Equipamentos;
        private Label lbl_Funcionario;
        private TextBox txt_Funcionario;
        private ComboBox cmb_Equipamentos;
        private Label label1;
        private Button bnt_Cadastrar;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem menuToolStripMenuItem;
        private ToolStripMenuItem sairToolStripMenuItem;
    }
}