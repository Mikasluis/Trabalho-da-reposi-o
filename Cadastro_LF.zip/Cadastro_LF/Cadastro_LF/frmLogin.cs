namespace Cadastro_LF
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void bnt_Cadastrar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_Nome.Text))
            {
                //Alerta para o Usu�rio
                MessageBox.Show("Detectamos um Troxa aqui kkkkkkkkkkkkkkk", "Aten��o", MessageBoxButtons.OK, MessageBoxIcon.Error);

                //Limpar o campo
                txt_Nome.Clear();

                //focar no erro do animal

                txt_Nome.Focus();

                //Parar a Execu��o 

                return;
            }

            if (string.IsNullOrWhiteSpace(txt_Idade.Text))
            {
                MessageBox.Show("Detectamos um Troxa aqui kkkkkkkkkkkkkkk", "Aten��o", MessageBoxButtons.OK, MessageBoxIcon.Error);

                txt_Idade.Clear();

                txt_Idade.Focus();

                return;
            }
            
            frmMenu telPrincipal = new frmMenu();


            this.Hide();

            telPrincipal.ShowDialog();


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
