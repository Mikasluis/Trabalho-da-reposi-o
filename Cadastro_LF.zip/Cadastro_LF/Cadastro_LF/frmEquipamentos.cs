﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cadastro_LF
{
    public partial class frmEquipamentos : Form
    {
        public frmEquipamentos()
        {
            InitializeComponent();
        }

        private void lbl_Funcionario_Click(object sender, EventArgs e)
        {

        }

        private void bnt_Cadastrar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(cmb_Equipamentos.Text))
            {
                MessageBox.Show("Produto não identificado", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (string.IsNullOrWhiteSpace(txt_Funcionario.Text))
            {
                MessageBox.Show("Funcionário não identificado", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_Funcionario.Clear();
                txt_Funcionario.Focus();
                return;
            }

            MessageBox.Show("Cadastro de item concluido", "Concluido", MessageBoxButtons.OK);

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            this.Close();
            menu.ShowDialog();

        }
    }
}
