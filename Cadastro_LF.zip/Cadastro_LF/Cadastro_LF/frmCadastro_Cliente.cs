﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cadastro_LF
{
    public partial class frmCadastro_Cliente : Form
    {
        public frmCadastro_Cliente()
        {
            InitializeComponent();
        }

        private void bnt_Cadastro_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_Nome.Text))
            {
                MessageBox.Show("Campo Nome não preenchido favor informar o nome do cliente", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);

                txt_Nome.Clear();
                txt_Nome.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txt_CPF.Text))
            {
                MessageBox.Show("Campo CPF não peenchido favor informe o CPF do cliente", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_CPF.Clear();
                txt_CPF.Focus();
                return;

            }

            if (string.IsNullOrWhiteSpace(txt_Time.Text))
            {
                MessageBox.Show("Campo de time não preenchido favor tomar vergonha na cara", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txt_Time.Clear();
                txt_Time.Focus();
                return;
            }
            if (txt_Time.Text == "Vasco")
            {
                MessageBox.Show("Meus pesames time que só decepiciona", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            MessageBox.Show("Cliente cadastrado com sucesso!", "Concluido", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);


        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void sairToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            this.Close();
            menu.ShowDialog();
        }
    }
}
